

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

import java.util.Iterator;

import org.junit.Test;

/**
 * Unit test for class Project.
 *
 */
public class TestVertex {


    @Test
    public void testVertexConstructor() {
        Point p1 = new Point(123,245);
        Vertex v1 = new Vertex(p1);

        assertThat (v1.getName(), equalTo(p1));
        assertThat (v1.getNumAdjacent(), equalTo(0));
        assertThat (v1.iterator().hasNext(), equalTo(false));
        assertNull(v1.getFigure());
        assertThat (v1.isCovered(), equalTo(false));

        Point p2 = (Point)p1.clone();
        Vertex v2 = new Vertex(p2);

        Point p3 = new Point(245, 123);
        Vertex v3 = new Vertex(p3);

        assertThat (v1, equalTo(v2));
        assertThat (v1, not(equalTo(v3)));

        String outs = v1.toString();
        assertThat (outs.contains("123"), equalTo(true));
        assertThat (outs.contains("245"), equalTo(true));

    }


    @Test
    public void testAddAdj() {
        Point[] pts = {new Point(1,2), new Point(3,4),
                new Point(5,6), new Point(7,8)};
        Point p = new Point(0, 0);
        Vertex v = new Vertex(p);
        for (int i = 0; i < pts.length; ++i) {
            v.addAdjacent(new Vertex(pts[i]));
            assertThat (v.getName(), equalTo(p));
            assertThat (v.getNumAdjacent(), equalTo(i+1));
            Iterator<Point> vIter = v.iterator();
            int j = 0;
            assertThat (j < i+1, equalTo(vIter.hasNext()));
            while (j < i+1 && vIter.hasNext()) {
                assertThat (pts[j], equalTo(vIter.next()));
                ++j;
            }
            assertThat (j < i+1, equalTo(vIter.hasNext()));
            assertThat (v.isCovered(), equalTo(false));
        }
    }

}
